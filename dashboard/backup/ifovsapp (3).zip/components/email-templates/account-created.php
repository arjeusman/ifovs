<div style="padding: 20px">
	<div style="padding: 10px 0px; border-bottom: 2px solid #fff;">
		<img style="max-width: 100px; height: auto;" src="https://ifovs.net/logo.png">
		<h4 style="margin: 0px;">IFOVS BSS HR Department</h4>
		<small>Veterans Village, Ipil, Zamboanga Sibugay</small>
	</div>
	<h1>Hi @firstname @lastname</h1>
	<p>Your account was created in iFOVS.</p>
	<p>Email: @email</p>
</div>
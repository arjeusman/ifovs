<div style="padding: 20px;">
	<div style="padding: 10px 0px; border-bottom: 2px solid #fff;">
		<img style="max-width: 100px; height: auto;" src="https://ifovs.net/logo.png">
		<h4 style="margin: 0px;">IFOVS BSS HR Department</h4>
		<small>Veterans Village, Ipil, Zamboanga Sibugay</small>
	</div>
	<h1>Hello @firstname @lastname,</h1>
	<h2>This is your login credential for @email.</h2>
	<p>username: <mark style="background: #dedede; padding: 4px; border-radius: 4px;">@username</mark> or <mark style="background: #dedede; padding: 4px; border-radius: 4px;text-decoration: none;color: #222;">@email</mark></p>
	<p>Password: <mark style="background: #dedede; padding: 4px; border-radius: 4px;">@password</mark></p>
	<p>Login here: <a href="#">https://ifovs.net/login</a></p>
	<small>- IFOVS BSS HR Department</small>
</div>
<div style="padding: 20px">
	<div style="padding: 10px 0px; border-bottom: 2px solid #fff;">
		<img style="max-width: 100px; height: auto;" src="https://ifovs.net/logo.png">
		<h4 style="margin: 0px;">IFOVS BSS HR Department</h4>
		<small>Veterans Village, Ipil, Zamboanga Sibugay</small>
	</div>
	<h1>Hello @firstname @lastname,</h1>
	<h2>CONGRATULATIONS...!!!</h2>
	<p>We are inviting you to please come to the office for your interview. We are open Monday to Friday from 10pm (night) - 5am.</p>
	<p>Please note that this is for serious applicants only, we highly recommend you to prepare for your interview.</p>
	<p>TIPS: please observe the English's only policy and speak English's only during the interview, do not use any Tagalog or vernacular during the process, our hiring staff are very strict..!!!</p>
	<p>Office Address: iFOVS Office, Purok Dayang, Veterans Village, Ipil, Zamboanga Sibugay.<br/>(Landmark): Road going to ZC, just few meters from Citi hardware, in front of Judge Bael, you can see iFOVS signage along the highway.</p>
	<p>Make sure to bring your own PEN.</p>
	<p>Thank you and do your best..!!</p>
	<p>Wishing you the best,</p>
	<small>- iFOVS BSS HR Department</small>
</div>










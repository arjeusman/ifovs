<div style="padding: 20px;">
	<div style="padding: 10px 0px; border-bottom: 2px solid #fff;">
		<img style="max-width: 100px; height: auto;" src="https://ifovs.net/logo.png">
		<h4 style="margin: 0px;">IFOVS BSS HR Department</h4>
		<small>Veterans Village, Ipil, Zamboanga Sibugay</small>
	</div>
	<h1>Hello @firstname @lastname,</h1>
	<h2>We've received your application.</h2>
	<p>This is to inform you that we have received your application. Our team will reach you via your email once we review your application. Thank you for reaching us.</p>
	<small>- IFOVS BSS HR Department</small>
</div>
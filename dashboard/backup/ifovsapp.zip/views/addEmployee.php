<!-- Add Modal -->
<div class="modal fade" id="addEmployee" tabindex="-1" data-bs-backdrop="static" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" style="width: 450px">
    <form method="post" class="modal-content rounded-0">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel"><i class="bi bi-person-plus-fill"></i> Employee</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <label class="form-label" for="first_name1">First Name</label>
        <input id="first_name1" type="text" name="first_name" class="form-control mb-2 rounded-0" autocomplete="off">
        <label class="form-label" for="middle_name1">Middle Name</label>
        <input id="middle_name1" type="text" name="middle_name" class="form-control mb-2 rounded-0" autocomplete="off">
        <label class="form-label" for="last_name1">Last Name</label>
        <input id="last_name1" type="text" name="last_name" class="form-control mb-2 rounded-0" autocomplete="off">
        <label class="form-label" for="email_address1">Email Address</label>
        <input id="email_address1" type="email" name="email_address" class="form-control mb-2 rounded-0" autocomplete="off">
        <label class="form-label" for="phone_number1">Phone Number</label>
        <input id="phone_number1" type="number" name="phone_number" class="form-control mb-2 rounded-0" autocomplete="off">
        <label class="form-label" for="home_address1">Home Address</label>
        <input id="home_address1" type="text" name="home_address" class="form-control mb-2 rounded-0" autocomplete="off">
      </div>
      <div class="modal-footer">
        <button type="submit" name="add_employee" class="btn btn-primary bg-gradient"><i class="bi bi-person-plus-fill"></i> Add Employee</button>
      </div>
    </form>
  </div>
</div>
<!-- Add Modal -->
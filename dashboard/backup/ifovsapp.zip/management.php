<?php require('config.php'); ?>
<?php protectedContent(); ?>
<?php $active = 'management'; ?>

<?php

if(isset($_POST['add_employee'])):
  $first_name = $_POST['first_name'];
  $middle_name = $_POST['middle_name'];
  $last_name = $_POST['last_name'];
  $email_address = $_POST['email_address'];
  $phone_number = $_POST['phone_number'];
  $home_address = $_POST['home_address'];
  $add = mysqli_query($con, "insert into employees(first_name, middle_name, last_name, email_address, phone_number, home_address) values ('$first_name','$middle_name','$last_name','$email_address','$phone_number','$home_address')");
  if($add):
    $_SESSION['message'] = array(
      'type' => 'success',
      'title' => 'Added!',
      'message' => 'New record was added successfully.',
      'page' => basename($_SERVER['REQUEST_URI'])
    );
  else:
    $_SESSION['message'] = array(
      'type' => 'warning',
      'title' => 'Warning!',
      'message' => 'Please try again.',
      'page' => basename($_SERVER['REQUEST_URI'])
    );
  endif;
  header("location: ?ref=".uniqid());
endif;

if(isset($_POST['edit_employee'])):
  $id = $_POST['id'];
  $first_name = $_POST['first_name'];
  $middle_name = $_POST['middle_name'];
  $last_name = $_POST['last_name'];
  $email_address = $_POST['email_address'];
  $phone_number = $_POST['phone_number'];
  $home_address = $_POST['home_address'];
  $edit = mysqli_query($con, "update employees set first_name='$first_name', middle_name='$middle_name', last_name='$last_name', email_address='$email_address', phone_number='$phone_number', home_address='$home_address' where id=$id");
  if($edit):
    $_SESSION['message'] = array(
      'type' => 'success',
      'title' => 'Updated!',
      'message' => 'The record was updated successfully.',
      'page' => basename($_SERVER['REQUEST_URI'])
    );
  else:
    $_SESSION['message'] = array(
      'type' => 'warning',
      'title' => 'Warning!',
      'message' => 'Failed to updated record, please try again.',
      'page' => basename($_SERVER['REQUEST_URI'])
    );
  endif;
  header("location: ?ref=".uniqid());
endif;

if(isset($_GET['delete'])):
  $id = $_GET['delete'];
  $delete = mysqli_query($con, "delete from employees where id=$id");
  if($delete):
    $_SESSION['message'] = array(
      'type' => 'success',
      'title' => 'Deleted!',
      'message' => 'The record was deleted successfully.',
      'page' => basename($_SERVER['REQUEST_URI'])
    );
  else:
    $_SESSION['message'] = array(
      'type' => 'error',
      'title' => 'Warning!',
      'message' => 'Failed to delete record, please try again.',
      'page' => basename($_SERVER['REQUEST_URI'])
    );
  endif;
  header("location: ?ref=".uniqid());
endif;

?>

<?php getComponent('header'); ?>

<header class="bg-dark bg-gradient d-flex flex-column position-relative shadow">
  <div class="bg-white rounded position-absolute flex-fill d-flex flex-column justify-content-center px-4 py-5">
    <h1 class="fs-2">Management</h1>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb m-0">
        <li class="breadcrumb-item" aria-current="page"><?php print appName; ?></li>
        <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
        <li class="breadcrumb-item" aria-current="page">Management</li>
      </ol>
    </nav>
  </div>
</header>

<div class="container-fluid">
  <div class="main bg-white rounded shadow mb-3 py-1"><!-- main -->

    <div class="d-flex gap-2 flex-row flex-nowrap m-2">
      <div class="overflow-hidden text-bg-dark bg-gradient flex-fill d-flex gap-2 align-items-center rounded shadow" style="height: 100px;">
        <div class="d-flex align-items-center bg-white bg-opacity-10 h-100 px-3">
          <i class="bi bi-people-fill" style="font-size: 60px;"></i>
        </div>
        <div>
          <h1 class="fs-1 m-0">10</h1>
          <small>Managements</small>
        </div>
      </div>
      <div class="overflow-hidden text-bg-primary bg-gradient flex-fill d-flex gap-2 align-items-center rounded shadow" style="height: 100px;">
        <div class="d-flex align-items-center bg-white bg-opacity-10 h-100 px-3">
          <i class="bi bi-person-badge" style="font-size: 60px;"></i>
        </div>
        <div>
          <h1 class="fs-1 m-0">10</h1>
          <small>Applications</small>
        </div>
      </div>
      <div class="overflow-hidden text-bg-success bg-gradient flex-fill d-flex gap-2 align-items-center rounded shadow" style="height: 100px;">
        <div class="d-flex align-items-center bg-white bg-opacity-10 h-100 px-3">
          <i class="bi bi-chat-dots-fill" style="font-size: 60px;"></i>
        </div>
        <div>
          <h1 class="fs-1 m-0">10</h1>
          <small>Messages</small>
        </div>
      </div>
    </div>

    <div class="d-flex align-items-center gap-2 px-2 py-2">
      <!-- Button trigger modal -->
      <button type="button" class="btn btn-primary bg-gradient" data-bs-toggle="modal" data-bs-target="#addEmployee"><i class="bi bi-person-plus-fill me-2"></i> Employee</button>
      <form class="d-flex align-items-center justify-content-center gap-1">
        <input name="search" class="form-control m-auto" placeholder="Search employee" autocomplete="off">
        <button class="btn btn-success bg-gradient"><i class="bi bi-search"></i></button>
        <?php if(isset($_GET['search'])): ?>
          <a title="Close search result." href="management.php" class="btn btn-danger bg-gradient"><i class="bi bi-x-lg"></i></a>
        <?php endif; ?>
      </form>
    </div>

    <div class="table-responsive"><!-- table -->
    <table class="table table-sm">
      <thead>
        <tr class="table-secondary text-uppercase">
          <td></td>
          <td>ID</td>
          <td>Name</td>
          <td>Email</td>
          <td>Phone</td>
          <td>Address</td>
          <td></td>
        </tr>
      </thead>
      <tbody>
        <?php
        if(isset($_GET['search'])):
          $key = $_GET['search'];
          $employees = mysqli_query($con, "select * from employees where first_name like '%$key%' or middle_name like '%$key%' or last_name like '%$key%' or phone_number like '%$key%' or email_address like '%$key%' or home_address like '%$key%' order by id desc");
        else:
          $employees = mysqli_query($con, "select * from employees order by id desc");
        endif;
        ?>
        <?php if(mysqli_num_rows($employees)==0): ?>
          <tr class="align-middle text-center">
            <td colspan="100%" class="py-5 border-0 text-muted fs-6">
              <?php if(isset($_GET['search'])): ?>
                <i class="bi bi-search me-2"></i> No search result for <?php print $_GET['search']; ?>
              <?php else: ?>
                <i class="bi bi-folder-x me-2"></i> No records to show.
              <?php endif; ?>
            </td>
          </tr>
        <?php else: ?>
          <?php if(isset($_GET['search'])): ?>
            <tr class="table-success">
              <td colspan="100%" class="p-2">
                <i class="bi bi-search me-2"></i> Showing search results for <?php print $_GET['search']; ?>
              </td>
            </tr>
          <?php endif; ?>
        <?php endif; ?>
        <?php while($e = mysqli_fetch_assoc($employees)): ?>
        <tr class="align-middle">
          <td><img class="avatar" src="assets/blank-avatar.jpg"></td>
          <td><?php print $e['id']; ?></td>
          <td><?php print $e['first_name'].' '.$e['last_name']; ?></td>
          <td><?php print $e['email_address']; ?></td>
          <td><?php print $e['phone_number']; ?></td>
          <td><?php print $e['home_address']; ?></td>
          <td class="text-end">
            <button onclick="Edit(<?php print str_replace('"', "'", json_encode($e)); ?>)" class="btn btn-sm btn-primary bg-gradient"><i class="bi bi-pencil-square"></i></button>
            <button onclick="Delete(<?php print str_replace('"', "'", json_encode($e)); ?>)" class="btn btn-sm btn-danger bg-gradient"><i class="bi bi-trash3"></i></button>
          </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
    </div><!-- table -->

  </div><!-- main -->

</div><!-- container -->

<?php getModel('addEmployee'); ?>
<?php getModel('editEmployee'); ?>

<script type="text/javascript">
  function Edit(data){
    new bootstrap.Modal(document.querySelector("#edit")).show();
    for(var d in data){
      document.getElementById(d).value = data[d]
    }
  }
  function Delete(data){
    Swal.fire({
      icon: 'warning',
      title: 'Delete?',
      iconHtml: '<i class="bi bi-trash3"></i>',
      html: 'Are you sure you want to delete <b>'+data.first_name+' '+data.last_name+'</b> in your record?',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete.',
      cancelButtonText: 'Nope.',
      buttonsStyling: false,
      customClass: {
        confirmButton: 'btn btn-secondary bg-gradient me-2',
        cancelButton: 'btn btn-danger bg-gradient',
      },
      width: 400
    }).then((result) => {
      if(result.isConfirmed){
        window.location.href = '?delete='+data.id
      }
    });
  }
</script>

<?php getComponent('footer'); ?>
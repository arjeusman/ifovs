<?php

global $con;

require('includes/mailer.php');

if(!isset($_SESSION['view'])):
  $_SESSION['view'] = 'new';
endif;

if(isset($_GET['view'])):
  $_SESSION['view'] = $_GET['view'];
  header('location: applications.php');
endif;

if(isset($_GET['approve'])):
  $id = $_GET['approve'];
  $approve = mysqli_query($con, "update applications set is_approved=true, is_discarded=false, is_deleted=false where id=$id");
  if($approve):
    $_SESSION['message'] = array(
      'type' => 'success',
      'title' => 'Approved!',
      'message' => 'Application was approve successfully.',
      'page' => basename($_SERVER['REQUEST_URI'])
    );
  else:
    $_SESSION['message'] = array(
      'type' => 'error',
      'title' => 'Warning!',
      'message' => 'Something went wrong, please try again.',
      'page' => basename($_SERVER['REQUEST_URI'])
    );
  endif;
endif;

if(isset($_GET['discard'])):
  $id = $_GET['discard'];
  $discard = mysqli_query($con, "update applications set is_approved=false, is_discarded=true, is_deleted=false where id=$id");
  if($discard):
    $_SESSION['message'] = array(
      'type' => 'success',
      'title' => 'Discarded!',
      'message' => 'Application was discarded successfully.',
      'page' => basename($_SERVER['REQUEST_URI'])
    );
  else:
    $_SESSION['message'] = array(
      'type' => 'error',
      'title' => 'Warning!',
      'message' => 'Something went wrong, please try again.',
      'page' => basename($_SERVER['REQUEST_URI'])
    );
  endif;
  header("location: applications.php");
endif;

if(isset($_GET['delete'])):
  $id = $_GET['delete'];
  $delete = mysqli_query($con, "update applications set is_approved=false, is_discarded=false, is_deleted=true where id=$id");
  if($delete):
    $_SESSION['message'] = array(
      'type' => 'success',
      'title' => 'Deleted!',
      'message' => 'Application was deleted successfully.',
      'page' => basename($_SERVER['REQUEST_URI'])
    );
  else:
    $_SESSION['message'] = array(
      'type' => 'error',
      'title' => 'Warning!',
      'message' => 'Something went wrong, please try again.',
      'page' => basename($_SERVER['REQUEST_URI'])
    );
  endif;
  header("location: applications.php");
endif;

?>
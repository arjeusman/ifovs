<?php

//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require 'vendor/autoload.php';

function sendEmail($subject, $recipient, $template, $data){
	$mail = new PHPMailer(true);
	try {
	    //Server settings
	    $mail->SMTPDebug = SMTP::DEBUG_SERVER;
	    $mail->isSMTP();
	    $mail->Host       = 'smtp.hostinger.com';
	    $mail->SMTPAuth   = true;
	    $mail->Username   = 'noreply@ifovs.net';
	    $mail->Password   = 'noreply@iFovs2023';
	    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
	    $mail->Port       = 465;

	    //Recipients
	    $mail->setFrom('noreply@ifovs.net', 'noreply@ifovs.net');
	    $mail->addAddress($recipient);

	    //get template
	    $temp = 'components/email-templates/'.$template.'.php';
	    if(file_exists($temp)){
	    	$body = file_get_contents($temp);
	    } else {
	    	$body = file_get_contents('components/email-templates/trouble.php');
	    }

	    //Content
	    $mail->isHTML(true);
	    $mail->Subject = (!empty($subject))?$subject:'No subject';
	    $mail->Body    = $body;
	    $mail->send();

	    $_SESSION['message'] = array(
	      'type' => 'success',
	      'title' => 'Sent successfully!',
	      'message' => 'Hi '.$data['first_name'].', your letter was successfully sent to '.appName.'. Thank you for reaching us!',
	      'page' => basename($_SERVER['REQUEST_URI'])
	    );
	} catch(Exception $e){
	    $_SESSION['message'] = array(
	      'type' => 'warning',
	      'title' => 'Wait!',
	      'message' => 'Something went wrong on the server, please try again.',
	      'page' => basename($_SERVER['REQUEST_URI'])
	    );
	}
	header("location: ".basename($_SERVER['SCRIPT_NAME']));
}
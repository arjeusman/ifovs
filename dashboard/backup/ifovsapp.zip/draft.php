<?php

require('config.php');

if(isset($_POST['send'])):
  $first_name = $_POST['first_name'];
  $middle_name = $_POST['middle_name'];
  $last_name = $_POST['last_name'];
  $email_address = $_POST['email_address'];
  $phone_number = $_POST['phone_number'];
  $home_address = $_POST['home_address'];
  $application_letter = $_POST['application_letter'];
  $send = mysqli_query($con, "insert into applications(first_name, middle_name, last_name, email_address, phone_number, home_address, application_letter) values ('$first_name','$middle_name','$last_name','$email_address','$phone_number','$home_address', '$application_letter')");
  if($send):
    $_SESSION['message'] = array(
      'type' => 'success',
      'title' => 'Sent successfully!',
      'message' => 'Hi '.$_POST['first_name'].', your letter was successfully sent to '.appName.'. Thank you for reaching us!',
      'page' => basename($_SERVER['REQUEST_URI'])
    );
  else:
    $_SESSION['message'] = array(
      'type' => 'success',
      'title' => 'Wait!',
      'message' => 'Something went wrong, please try again.',
      'page' => basename($_SERVER['REQUEST_URI'])
    );
  endif;
  header("location: application-form.php?ref=".uniqid());
endif;

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Application Form - iFovs</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"crossorigin="anonymous"/>
  <link rel="icon" href="assets/favicon.ico">
  <link rel="stylesheet" href="script/richtexteditor/rte_theme_default.css"/>
  <script type="text/javascript" src="script/richtexteditor/rte.js"></script>
  <script type="text/javascript" src='script/richtexteditor/plugins/all_plugins.js'></script>
  <link rel="stylesheet" type="text/css" href="assets/style.css" />
  <?php include('includes/popMessage.php'); ?>
</head>
<body <?php if(isset($_SESSION['message'])): print 'onload="showMessage()"'; endif; ?>>
  <div class="container p-0">
    <form method="post" action="" class="card text-bg-white shadow-lg border-0 rounded-0 needs-validation" novalidate>
      <div class="card-header bg-dark border-bottom border-4 border-dark-subtle bg-gradient py-4 border-0 rounded-0">
        <img style="width: 80px;" src="assets/logo.png">
      </div>
      <div class="card-body">
        <h1 class="fs-1 mb-3">Application Form</h1>
        <div class="row">
          <div class="col-sm-12 col-md-4 col-lg-4 has-validation mb-2">
            <label for="first_name">First Name</label>
            <input type="text" id="first_name" name="first_name" class="form-control mt-2 rounded-0" autocomplete="off" required>
            <div class="invalid-feedback">Please enter your First Name.</div>
          </div>
          <div class="col-sm-12 col-md-4 col-lg-4 has-validation mb-2">
            <label for="middle_name">Middle Name</label>
            <input type="text" id="middle_name" name="middle_name" class="form-control mt-2 rounded-0" autocomplete="off" required>
            <div class="invalid-feedback">Please enter your Middle Name.</div>
          </div>
          <div class="col-sm-12 col-md-4 col-lg-4 has-validation mb-2">
            <label for="last_name">Last Name</label>
            <input type="text" id="last_name" name="last_name" class="form-control mt-2 rounded-0" autocomplete="off" required>
            <div class="invalid-feedback">Please enter your Last Name.</div>
          </div>
        </div>
        <div class="row">
           <div class="col-sm-12 col-md-4 col-lg-4 has-validation mb-2">
            <label for="email_address">Email Address</label>
            <input type="text" id="email_address" name="email_address" class="form-control mt-2 rounded-0" autocomplete="off" required>
            <div class="invalid-feedback">Please enter your Email Address.</div>
          </div>
          <div class="col-sm-12 col-md-4 col-lg-4 has-validation mb-2">
            <label for="phone_number">Phone Number</label>
            <input type="text" id="phone_number" name="phone_number" class="form-control mt-2 rounded-0" autocomplete="off" required>
            <div class="invalid-feedback">Please enter your Phone Number.</div>
          </div>
          <div class="col-sm-12 col-md-4 col-lg-4 has-validation mb-2">
            <label for="home_address">Home Address</label>
            <input type="text" id="home_address" name="home_address" class="form-control mt-2 rounded-0" autocomplete="off" required>
            <div class="invalid-feedback">Please enter your Home Address.</div>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-12 col-md-12 col-lg-12">
            <label for="letter" class="mb-2">Write a Letter</label>
            <textarea name="application_letter" id="letter" style="min-height: 300px"></textarea>
          </div>
        </div>
        <div class="row">
          <div class="d-flex mt-3">
              <button type="submit" name="send" class="btn btn-lg btn-primary bg-gradient"><i class="bi bi-envelope"></i> Send Form</button>
          </div>
        </div>
      </div>
    </form>
  </div>

  <style type="text/css">
    .rte_command_insertlink,
    .rte_command_insertemoji,
    .rte_command_insertimage,
    .rte_command_insertvideo,
    .rte_command_insertlink,
    .rte_command_removeformat,
    .rte_command_code,
    rte-line-spliter,
    rte-bottom {
      display: none !important;
    }
  </style>
  <script type="text/javascript" src="script/script.js"></script>
  <script type="text/javascript">
    var config = {
      skin: 'default',
      toolbar: 'basic',
      toolbarMobile: 'mobile',
      enableDragDrop: false,
      enableObjectResizing: false,
      showPlusButton: false,
      showTagList: false,
      showStatistics: false,
      editorResizeMode: 'none',
      toggleBorder: false,
      showSelectedBlock: false,
      showFloatParagraph: false,
      showTagList: false,
      allowScriptCode: false,
      showFloatTableToolBar: false
    }
    var editor1 = new RichTextEditor("#letter", config);
  </script>

  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</body>
</html>

<?php

if(isset($_SESSION['message'])):
  if($_SESSION['message']['page']!=basename($_SERVER['REQUEST_URI'])):
    unset($_SESSION['message']);
  endif;
endif;

?>
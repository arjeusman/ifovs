<?php require('config.php'); ?>
<?php protectedContent(); ?>
<?php $active = 'applications'; ?>
<?php getProcessor('applications'); ?>
<?php getComponent('header'); ?>

<header class="bg-dark bg-gradient d-flex flex-column position-relative shadow">
  <div class="bg-white rounded position-absolute flex-fill d-flex flex-column justify-content-center px-4 py-5">
    <h1 class="fs-2">Dashboard</h1>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb m-0">
        <li class="breadcrumb-item" aria-current="page"><?php print appName; ?></li>
        <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
        <li class="breadcrumb-item" aria-current="page">Management</li>
      </ol>
    </nav>
  </div>
</header>

<div class="container-fluid">

  <div class="main bg-white rounded shadow mb-3 py-1"><!-- main -->

    <div class="d-flex justify-content-end gap-2 px-2 py-2">
      <form class="d-flex align-items-center justify-content-center gap-1">
        <input name="search" class="form-control m-auto" placeholder="Search application" autocomplete="off">
        <button class="btn btn-success bg-gradient"><i class="bi bi-search"></i></button>
        <?php if(isset($_GET['search'])): ?>
          <a title="Close search result." href="applications.php" class="btn btn-danger bg-gradient"><i class="bi bi-x-lg"></i></a>
        <?php endif; ?>
      </form>
    </div>

    <div class="d-flex gap-2 flex-row flex-nowrap p-2 sticky-top bg-white">
      <a href="?view=new" class="text-dark text-decoration-none overflow-hidden border-bottom border-5 flex-fill d-flex gap-2 align-items-center rounded shadow <?php print ($_SESSION['view']=='new')?'bg-primary bg-opacity-75 bg-gradient border-primary':'bg-secondary bg-opacity-50 border-secondary'; ?>" style="height: 100px;">
        <div class="col-5 d-flex flex-column align-items-center justify-content-center bg-white bg-opacity-10 px-3 h-100">
          <i class="bi bi-journal-bookmark" style="font-size: 50px; line-height: normal;"></i>
          <small class="text-uppercase">New</small>
        </div>
        <h1 class="fs-1 m-0 text-center flex-fill"><?php print countData("select * from applications where is_approved=false and is_discarded=false and is_deleted=false"); ?></h1>
      </a>
      <a href="?view=approved" class="text-dark text-decoration-none overflow-hidden border-bottom border-5 flex-fill d-flex gap-2 align-items-center rounded shadow <?php print ($_SESSION['view']=='approved')?'bg-success bg-opacity-75 bg-gradient border-success':'bg-secondary bg-opacity-50 border-secondary'; ?>" style="height: 100px;">
        <div class="col-5 d-flex flex-column align-items-center justify-content-center bg-white bg-opacity-10 px-3 h-100">
          <i class="bi bi-journal-check" style="font-size: 50px; line-height: normal;"></i>
          <small class="text-uppercase">Approved</small>
        </div>
        <h1 class="fs-1 m-0 text-center flex-fill"><?php print countData("select * from applications where is_approved=true"); ?></h1>
      </a>
      <a href="?view=discarded" class="text-dark text-decoration-none overflow-hidden border-bottom border-5 flex-fill d-flex gap-2 align-items-center rounded shadow <?php print ($_SESSION['view']=='discarded')?'bg-warning bg-opacity-75 bg-gradient border-warning':'bg-secondary bg-opacity-50 border-secondary'; ?>" style="height: 100px;">
        <div class="col-5 d-flex flex-column align-items-center justify-content-center bg-white bg-opacity-10 px-3 h-100">
          <i class="bi bi-trash3" style="font-size: 50px; line-height: normal;"></i>
          <small class="text-uppercase">Discarded</small>
        </div>
        <h1 class="fs-1 m-0 text-center flex-fill"><?php print countData("select * from applications where is_discarded=true"); ?></h1>
      </a>
    </div>

    <div class="table-responsive"><!-- table -->
      <?php
        if(isset($_GET['search'])):
          $key = $_GET['search'];
          $applications = mysqli_query($con, "select * from applications where first_name like '%$key%' or middle_name like '%$key%' or last_name like '%$key%' or phone_number like '%$key%' or email_address like '%$key%' or home_address like '%$key%' order by id desc");
        else:
          if($_SESSION['view']=='approved'):
            $applications = mysqli_query($con, "select * from applications where is_approved=true order by id desc");
          elseif($_SESSION['view']=='discarded'):
            $applications = mysqli_query($con, "select * from applications where is_discarded=true order by id desc");
          else:
          $applications = mysqli_query($con, "select * from applications where is_approved=false and is_discarded=false and is_deleted=false order by id desc");
          endif;
        endif;
      ?>
    <table class="table table-sm">
      <?php if(mysqli_num_rows($applications) > 0): ?>
      <thead>
        <tr class="table-secondary text-uppercase">
          <td></td>
          <td>Name</td>
          <td>Gender</td>
          <td>Email</td>
          <td>Phone</td>
          <td>Address</td>
          <td></td>
        </tr>
      </thead>
      <?php endif; ?>
      <tbody>
        <?php if(mysqli_num_rows($applications)==0): ?>
          <tr class="align-middle text-center">
            <td colspan="100%" class="py-5 border-0 text-muted fs-6">
              <?php if(isset($_GET['search'])): ?>
                <i class="bi bi-search me-2"></i> No search result for <?php print ($_GET['search'])?$_GET['search']:'none'; ?>.
              <?php else: ?>
                <i class="bi bi-folder-x me-2"></i> No records to show.
              <?php endif; ?>
            </td>
          </tr>
        <?php else: ?>
          <?php if(isset($_GET['search'])): ?>
            <tr class="table-success">
              <td colspan="100%" class="p-2">
                <i class="bi bi-search me-2"></i> Showing search results for <?php print $_GET['search']; ?>
              </td>
            </tr>
          <?php endif; ?>
        <?php endif; ?>
        <?php while($app = mysqli_fetch_assoc($applications)): ?>
        <tr class="align-middle">
          <td class="text-center align-middle">
            <?php
              if($app['is_approved']):
                print '<small style="width:10px;height:10px;" class="d-inline-block rounded-circle bg-success" title="Marked as approved."></small>';
              elseif($app['is_discarded']):
                print '<small style="width:10px;height:10px;" class="d-inline-block rounded-circle bg-danger" title="Discarded application."></small>';
              else:
                print '<small style="width:10px;height:10px;" class="d-inline-block rounded-circle bg-primary" title="New application."></small>';
              endif;
            ?>
          </td>
          <td><?php print $app['first_name'].' '.$app['last_name']; ?></td>
          <td class="text-capitalize"><?php print $app['gender']; ?></td>
          <td><?php print $app['email_address']; ?></td>
          <td><?php print $app['phone_number']; ?></td>
          <td><?php print $app['home_address']; ?></td>
          <td class="text-end">
            <button onclick="Read(<?php print str_replace('"', "'", json_encode($app)); ?>)" class="btn btn-sm btn-primary bg-gradient"><i class="bi bi-journal-text"></i> Review</button>
            <?php if(!$app['is_approved'] && !$app['is_discarded'] && !$app['is_deleted']): ?>
              <button onclick="Approve(<?php print str_replace('"', "'", json_encode($app)); ?>)" class="btn btn-sm btn-success bg-gradient"><i class="bi bi-journal-check"></i> Approve</button>
            <?php endif; ?>
            <?php if(!$app['is_discarded']): ?>
              <button onclick="Discard(<?php print str_replace('"', "'", json_encode($app)); ?>)" class="btn btn-sm btn-warning bg-gradient text-white"><i class="bi bi-trash3"></i> Discard</button>
            <?php endif; ?>
            <?php if($app['is_discarded']): ?>
              <button onclick="Delete(<?php print str_replace('"', "'", json_encode($app)); ?>)" class="btn btn-sm btn-danger bg-gradient"><i class="bi bi-trash3"></i> Delete</button>
            <?php endif; ?>
          </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
    </div><!-- table -->

  </div><!-- main -->

</div><!-- container -->

<?php getModel('readApplication'); ?>

<script type="text/javascript">
  function Read(data){
    new bootstrap.Modal(document.querySelector("#read")).show();
    document.getElementById('id').innerHTML = 'ifovs-applicant-' + data.id
    document.getElementById('fullname').innerHTML = (data.middle_name!='')?data.first_name + ' ' + data.middle_name + ' ' + data.last_name:data.first_name + ' ' + data.last_name
    document.getElementById('gender').innerHTML = data.gender
    document.getElementById('age_status').innerHTML = data.age + '/' + data.civil_status
    document.getElementById('email').innerHTML = data.email_address
    document.getElementById('phone').innerHTML = data.phone_number
    document.getElementById('address').innerHTML = data.home_address
    document.getElementById('resume').href = data.resume
  }
  function Approve(data){
    let pronoun = (data.gender=='male')?'his':'her'
    Swal.fire({
      icon: 'warning',
      title: 'Approve?',
      iconHtml: '<i class="bi bi-person-fill-check"></i>',
      html: 'Are you sure you want to approve <b>'+data.first_name+'</b>\'s application? This applicant will receive a notice about '+pronoun+' application via email.',
      showCancelButton: true,
      confirmButtonText: '<i class="bi bi-check-lg"></i> Approve',
      cancelButtonText: 'Nope',
      buttonsStyling: false,
      customClass: {
        confirmButton: 'btn btn-lg btn-secondary bg-gradient me-2',
        cancelButton: 'btn btn-lg btn-primary bg-gradient',
      },
      width: 400
    }).then((result) => {
      if(result.isConfirmed){
        window.location.href = '?approve='+data.id
      }
    });
  }
  function Discard(data){
    Swal.fire({
      icon: 'warning',
      title: 'Discard?',
      iconHtml: '<i class="bi bi-trash3"></i>',
      html: 'Are you sure you want to discard <b>'+data.first_name+'</b>\'s application from the record?',
      showCancelButton: true,
      confirmButtonText: '<i class="bi bi-trash3"></i> Confirm',
      cancelButtonText: 'Nope',
      buttonsStyling: false,
      customClass: {
        confirmButton: 'btn btn-lg btn-secondary bg-gradient me-2',
        cancelButton: 'btn btn-lg btn-primary bg-gradient',
      },
      width: 400
    }).then((result) => {
      if(result.isConfirmed){
        window.location.href = '?discard='+data.id
      }
    });
  }
  function Delete(data){
    Swal.fire({
      icon: 'warning',
      title: 'Delete?',
      iconHtml: '<i class="bi bi-trash3"></i>',
      html: 'Are you sure you want to delete <b>'+data.first_name+'</b>\'s application from the record?',
      showCancelButton: true,
      confirmButtonText: '<i class="bi bi-trash3"></i> Confirm',
      cancelButtonText: 'Nope',
      buttonsStyling: false,
      customClass: {
        confirmButton: 'btn btn-lg btn-secondary bg-gradient me-2',
        cancelButton: 'btn btn-lg btn-primary bg-gradient',
      },
      width: 400
    }).then((result) => {
      if(result.isConfirmed){
        window.location.href = '?delete='+data.id
      }
    });
  }
</script>

<?php getComponent('footer'); ?>
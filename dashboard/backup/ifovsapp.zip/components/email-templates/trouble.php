<div style="padding: 20px;">
	<h1>We are having trouble right now :(</h1>
	<p>This is IFOVS AutoMailer. We're sorry to inform you that right now we are having trouble in our server, but don't worry we are working on it. Please stay tune, thank you!</p>
	<small>- IFOVS AutoMailer</small>
</div>
<?php require('config.php'); ?>
<?php protectedContent(); ?>
<?php $active = 'dashboard'; ?>
<?php getComponent('header'); ?>

<header class="bg-dark bg-gradient d-flex flex-column position-relative shadow">
  <div class="bg-white rounded position-absolute flex-fill d-flex flex-column justify-content-center px-4 py-5">
    <h1 class="fs-2">Dashboard</h1>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb m-0">
        <li class="breadcrumb-item" aria-current="page"><?php print appName; ?></li>
        <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
        <li class="breadcrumb-item" aria-current="page">Management</li>
      </ol>
    </nav>
  </div>
</header>

<div class="container-fluid">
  <div class="main bg-white rounded shadow mb-3 py-1"><!-- main -->
  </div><!-- main -->

</div><!-- container -->

<?php getComponent('footer'); ?>
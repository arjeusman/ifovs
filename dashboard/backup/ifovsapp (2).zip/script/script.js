(() => {
'use strict'
const forms = document.querySelectorAll('.needs-validation')
Array.from(forms).forEach(form => {
	form.addEventListener('submit', (e) => {
		if(!form.checkValidity()){
			e.preventDefault()
			e.stopPropagation()
		} else {
			Process()
			form.submit()
		}
    form.classList.add('was-validated')
}, false)
})
})()

function Process(){
	let html;
	html = '<div style="min-height: 200px" class="d-flex flex-column align-items-center justify-content-center gap-4">'
	html = html.concat('<img style="width: 80px" src="assets/spinner.gif">')
	html = html.concat('<span style="font-size: 14px">Processing please wait.</span>')
	html = html.concat('</div>')
	Swal.fire({
	  html: html,
	  allowOutsideClick: false,
	  showConfirmButton: false,
	  width: 400
	});
}
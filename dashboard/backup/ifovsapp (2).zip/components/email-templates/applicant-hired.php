<div style="padding: 20px;">
	<div style="padding: 10px 0px; border-bottom: 2px solid #fff;">
		<img style="max-width: 100px; height: auto;" src="https://ifovs.net/logo.png">
		<h4 style="margin: 0px;">IFOVS BSS HR Department</h4>
		<small>Veterans Village, Ipil, Zamboanga Sibugay</small>
	</div>
	<h1>CONGRATULATIONS @firstname!!!</h1>
	<h2>You are hired!</h2>
	<p>Thank you and do your best..!!</p>
	<p>Wishing you the best,</p>
	<small>- IFOVS BSS HR Department</small></p>
</div>










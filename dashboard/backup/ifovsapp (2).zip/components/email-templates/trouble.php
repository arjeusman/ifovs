<div style="padding: 20px;">
	<div style="padding: 10px 0px; border-bottom: 2px solid #fff;">
		<img style="max-width: 100px; height: auto;" src="https://ifovs.net/logo.png">
		<h4 style="margin: 0px;">IFOVS AutoMailer</h4>
		<small>Veterans Village, Ipil, Zamboanga Sibugay</small>
	</div>
	<h1>We are having trouble right now.</h1>
	<p>We're sorry to inform you that right now we are having trouble in our server, but don't worry we are working on it. Please stay tune, thank you!</p>
	<small>- IFOVS AutoMailer</small>
</div>